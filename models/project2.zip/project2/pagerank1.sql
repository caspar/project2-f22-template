{{ config(materialized='table') }}

-- write your query here